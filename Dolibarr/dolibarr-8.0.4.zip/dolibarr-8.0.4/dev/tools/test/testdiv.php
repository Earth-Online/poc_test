
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- BEGIN PHP TEMPLATE LOGIN.TPL.PHP -->
<html>

<head>
<meta name="robots" content="noindex,nofollow" />
<meta name="author" content="Dolibarr Development Team">
<link rel="shortcut icon" type="image/x-icon" href="/dolibarrnew/theme/eldy/img/favicon.ico"/>
<title>Login Dolibarr 3.4.0-alpha</title>
<!-- Includes for JQuery (Ajax library) -->
<link rel="stylesheet" type="text/css" href="/dolibarrnew/includes/jquery/css/smoothness/jquery-ui.custom.css" />
<link rel="stylesheet" type="text/css" title="default" href="/dolibarrnew/custom/filemanager/css/filemanager.css.php"><!-- Added by module filemanager-->
<!-- Includes JS for JQuery -->
<script type="text/javascript" src="/dolibarrnew/includes/jquery/js/jquery.min.js"></script>
<script type="text/javascript" src="/dolibarrnew/core/js/dst.js"></script>
<link rel="stylesheet" type="text/css" href="/dolibarrnew/theme/eldy/style.css.php?lang=fr_FR" />
<!-- HTTP_USER_AGENT = Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.97 Safari/537.22 -->
</head>
<body class="body">

<div class="center">

<div class="login_table" align="center">

<!-- <tr><td colspan="2" valign="middle"> -->
<div id="login_line1" align="center">

<div id="login_left" style="display: inline-block; min-width: 250px; margin: 0 auto;"><div class="center">

<table class="none" summary="Login pass" cellpadding="2" align="center">

<!-- Login -->
<tr>
<td valign="bottom"> &nbsp; <strong><label for="username">Login</label></strong>fds fs df sdf gdsfgsdf r &nbsp; </td>
<td valign="bottom" class="nowrap">
<input type="text" id="username" name="username" class="flat" size="15" maxlength="40" value="" tabindex="1" />
</td>
</tr>

<!-- Password -->
<tr><td class="tdtop nowrap"> &nbsp; <strong><label for="password">Mot de passe</label></strong> &nbsp; </td>
<td class="tdtop nowrap">
<input id="password" name="password" class="flat" type="password" size="15" maxlength="30" value="" tabindex="2" />
</td></tr>

</table>

</div>
</div> <!-- end div left -->

<!-- </td>
<td align="center" valign="middle">-->
<div id="login_right" style="display: inline-block; min-width: 250px; margin: 0 auto;">

<img alt="Logo" title="" src="/dolibarrnew/theme/dolibarr_logo.png" id="img_logo" />

</div>
</div> <!-- end div line1 -->
<!--</td>

</tr>-->


</div>

</div>

</body>
</html>
<!-- END PHP TEMPLATE -->
